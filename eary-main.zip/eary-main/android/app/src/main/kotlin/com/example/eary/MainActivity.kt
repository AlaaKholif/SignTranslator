package com.example.eary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
