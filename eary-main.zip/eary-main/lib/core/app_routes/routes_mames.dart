class RoutsNames {
  static const splash = '/';
  static const onBoarding = '/on_boarding';
  static const authentication = '/authentication';
  static const login = '/login';
  static const register = '/register';
  static const home = '/home';
  static const search = '/search';
  static const profile = '/profile';
  static const settings = '/settings';
  static const contactProfile = '/contactProfile';
}
