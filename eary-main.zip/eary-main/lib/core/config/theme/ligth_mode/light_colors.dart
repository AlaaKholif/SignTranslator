import 'package:flutter/material.dart';

class AppLightColors {
  static Color primaryColor = const Color(0xffF0F9FF);
  static Color primaryColorLight = const Color(0xffCED1EE).withOpacity(.35);
  static Color primaryColorDark = const Color(0xffCED1EE);
  static Color cardColor = const Color(0xffE4EBF9).withOpacity(.35);

  static const Color scaffoldLight = Color(0xffffffff);
  static const Color searchColor = Color(0xffCED1EE);
  static const Color mainTextColor = Color(0xff525252);
  static Color mainTextOpacityColor = const Color(0xff525252).withOpacity(.24);
  static const Color subTextColor = Color(0xff998BE0);
  static const Color mainButtonColor = Color(0xff998BE0);
  static const Color subButtonColor = Color(0xffCED1EE);
  static const Color white = Color(0xffffffff);
}
