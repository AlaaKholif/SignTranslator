import 'package:eary/core/config/theme/ligth_mode/light_colors.dart';
import 'package:flutter/material.dart';
import '../../../utilites/font_manager.dart';
import '../../../utilites/font_style_manager.dart';

final ThemeData lightTheme = ThemeData.light().copyWith(
  scaffoldBackgroundColor: AppLightColors.scaffoldLight,
  cardColor: AppLightColors.cardColor,
  primaryColor: AppLightColors.primaryColor,
  primaryColorLight: AppLightColors.primaryColorLight,
  primaryColorDark: AppLightColors.primaryColorDark,
  hintColor: AppLightColors.mainTextColor,
  highlightColor: AppLightColors.subTextColor,
  hoverColor: AppLightColors.mainTextOpacityColor,
  canvasColor: AppLightColors.mainButtonColor,
  disabledColor: AppLightColors.subButtonColor,
  dialogBackgroundColor: AppLightColors.white,
  inputDecorationTheme: InputDecorationTheme(
    border: OutlineInputBorder(
        borderSide: const BorderSide(
          color: Color(0xff998BE0),
        ),
        borderRadius: BorderRadius.circular(20)),
    hintStyle: const TextStyle(fontSize: 10, color: Color(0xff525252)),
    errorStyle: const TextStyle(
        fontSize: 15, fontFamily: AppFontFamily.fingerPaintFamily),
  ),
  textTheme: TextTheme(
    //bold
    bodyLarge: getBoldStyle(color: AppLightColors.mainTextColor),
    displayLarge: getBoldStyle(
        color: AppLightColors.subTextColor, fontSize: AppFontSize.s20),
    headlineLarge: getBoldStyle(
        color: AppLightColors.mainTextColor, fontSize: AppFontSize.s18),
    //medium
    displayMedium: getMediumStyle(
        color: AppLightColors.mainTextOpacityColor, fontSize: AppFontSize.s22),
    titleMedium: getMediumStyle(
        color: AppLightColors.mainTextColor, fontSize: AppFontSize.s32),
    bodyMedium: getMediumStyle(
        color: AppLightColors.mainTextOpacityColor,
        fontSize: AppFontSize.s18,
        fontFamily: AppFontFamily.poppinsFamily),
    headlineMedium: getMediumStyle(
        color: AppLightColors.mainTextColor,
        fontSize: AppFontSize.s18,
        fontFamily: AppFontFamily.inconsolata),
// headline1: getMediumStyle(
//     color: AppLightColors.white,
//     fontSize: AppFontSize.s18,
//     fontFamily: AppFontFamily.inter),
//  headline2:getMediumStyle(
//     color: AppLightColors.mainTextColor,
//     fontSize: AppFontSize.s16,
//     fontFamily: AppFontFamily.inter) ,
// headline3:  getRegularStyle(
//     color: AppLightColors.mainTextOpacityColor, fontSize: AppFontSize.s18),
// headline4:  getBoldStyle(
//       color: AppLightColors.subTextColor.withOpacity(.7), fontSize: AppFontSize.s20),
//small
    bodySmall: getRegularStyle(
        color: AppLightColors.mainTextColor, fontSize: AppFontSize.s18),
    labelSmall: getMediumStyle(
        color: AppLightColors.mainTextColor,
        fontFamily: AppFontFamily.poppinsFamily),
    headlineSmall: getRegularStyle(
        color: AppLightColors.subTextColor,
        fontSize: AppFontSize.s32,
        fontFamily: AppFontFamily.fingerPaintFamily),
    displaySmall: getRegularStyle(
        color: AppLightColors.subTextColor,
        fontSize: AppFontSize.s24,
        fontFamily: AppFontFamily.fingerPaintFamily),
  ),
);
