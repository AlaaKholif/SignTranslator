import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppFontFamily {
  static const String fingerPaintFamily = "FingerPaint";
  static const String poppinsFamily = "poppins";
  static const String inconsolata = "Inconsolata";
  static const String inter = "inter";
}

class AppFontWeightManager {
  static const FontWeight regular = FontWeight.w400;
  static const FontWeight medium = FontWeight.w500;
  static const FontWeight bold = FontWeight.w700;
}

class AppFontSize {
  static double s32 = 32.0.sp;
  static double s22 = 22.0.sp;
  static double s24 = 24.0.sp;
  static double s18 = 18.0.sp;
  static double s16 = 16.0.sp;
  static double s20 = 20.0.sp;
}
