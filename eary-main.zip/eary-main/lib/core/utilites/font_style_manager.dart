import 'package:flutter/material.dart';

import 'font_manager.dart';

TextStyle _getTextStyle(double fontSize, FontWeight fontWeight, Color color,
{fontFamily = AppFontFamily.inter}) {
  return TextStyle(
      fontSize: fontSize,
      fontFamily: fontFamily,
      color: color,
      fontWeight: fontWeight);
}

TextStyle getRegularStyle(
    {double fontSize = 18, required Color color, fontFamily}) {
  return _getTextStyle(
      fontSize, AppFontWeightManager.regular, color, fontFamily:fontFamily);
}

TextStyle getMediumStyle({double fontSize = 13, required Color color,fontFamily}) {
  return _getTextStyle(fontSize, AppFontWeightManager.medium, color);
}

TextStyle getBoldStyle({double fontSize = 24, required Color color,fontFamily}) {
  return _getTextStyle(fontSize, AppFontWeightManager.bold, color,fontFamily:fontFamily);
}
