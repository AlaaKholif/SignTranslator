import 'package:eary/core/utilites/font_manager.dart';
import 'package:flutter/material.dart';import '../utilites/values_manager.dart';

class CustomTextField extends StatelessWidget {
  final String? hintText;
  final double? hintSize;
  final double? width;
  final double? radius;
  final double? height;
  final EdgeInsets? padding;
  final Color? color;
  final IconData? suffixIcon;
  final TextEditingController? controller;
  final String? Function(String?)? validator;

  final Function? onChanged;

  const CustomTextField({
    Key? key,
    this.suffixIcon,
    this.radius,
    this.hintSize,
    this.padding,
    this.hintText,
    this.onChanged,
    this.controller,
    this.color,
    this.width = double.infinity,
    this.height,
    this.validator,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: TextFormField(
        onChanged: (value) {
          onChanged!(value);
        },
        controller: controller,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        validator: validator,
        decoration: InputDecoration(
          errorStyle: const TextStyle(fontSize: 15,fontFamily: AppFontFamily.fingerPaintFamily),
          prefixIconConstraints: const BoxConstraints(maxWidth: AppSize.s16),
          suffixIcon: Icon(suffixIcon),
          hintText: hintText,
        ),
      ),
    );
  }
}
