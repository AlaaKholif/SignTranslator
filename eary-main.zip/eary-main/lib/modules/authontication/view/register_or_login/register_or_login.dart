import 'package:eary/core/config/localization/languages/appStrings_strings.dart';
import 'package:eary/core/utilites/app_images.dart';
import 'package:eary/core/utilites/font_manager.dart';
import 'package:eary/core/widgets/default_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../core/app_routes/routes_mames.dart';
import '../../../../core/widgets/custom_text.dart';

class AuthenticationScreen extends StatelessWidget {
  const AuthenticationScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Container(
        margin: EdgeInsets.only(top: 90.0.h),
        width: MediaQuery.of(context).size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              AppImages.logo,
              height: 148.h,
              width: 148.w,
            ),
            CustomText(
              text: AppStrings.eary,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            SizedBox(
              height: 24.h,
            ),
            CustomText(
              text: AppStrings.noCommunicationBarrierAnymore,
              style: Theme.of(context).textTheme.displaySmall,
            ),
            SizedBox(
              height: 35.h,
            ),
            DefaultButton(
              height: 44.h,
              width: 307.w,
              text: AppStrings.register,
              color: Theme.of(context).primaryColorLight,
              fontSize: 17.sp,
              fontWeight: FontWeight.w500,
              fontFamily: AppFontFamily.poppinsFamily,
              backGroundcolor: Theme.of(context).canvasColor,
              onPressed: () {
                Navigator.pushNamed(context, RoutsNames.register);
              },
            ),
            SizedBox(
              height: 20.h,
            ),
            DefaultButton(
              height: 44.h,
              width: 307.w,
              fontSize: 17.sp,
              fontWeight: FontWeight.w500,
              fontFamily: AppFontFamily.poppinsFamily,
              color: Theme.of(context).highlightColor,
              backGroundcolor: Theme.of(context).disabledColor,
              text: AppStrings.login,
              onPressed: () {
                Navigator.pushNamed(context, RoutsNames.login);
              },
            )
          ],
        ),
      ),
    );
  }
}
