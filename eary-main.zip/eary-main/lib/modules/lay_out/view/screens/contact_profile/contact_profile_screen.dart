import 'package:eary/core/utilites/app_images.dart';
import 'package:eary/core/utilites/constatnts.dart';
import 'package:eary/core/widgets/custom_appBar.dart';
import 'package:eary/core/widgets/custom_text.dart';
import 'package:eary/modules/lay_out/view/screens/contact_profile/video_call_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:http/http.dart' as http;

class ContactProfileScreen extends StatelessWidget {
  const ContactProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(context),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              customContainer(
                  context: context,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 50),
                        child: CustomText(
                          text: "Alaa Osama",
                          style: Theme.of(context).textTheme.displayLarge,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 35),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            GestureDetector(
                              child: Image.asset(
                                AppImages.contact1,
                                height: 28.0.h,
                                width: 35.0.w,
                              ),
                            ),
                            GestureDetector(
                              onTap: () async {
                                uid = randomNumber() + 1;

                                String url =
                                    '$serverUrl/rtc/$channelName/${tokenRole.toString()}/uid/${uid.toString()}';

                                // Send the request
                                var response = await http.get(Uri.parse(url));
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => VideoCallPage(
                                        // urlResponse: response,
                                        response: response,
                                      ),
                                    ));
                              },
                              child: Image.asset(
                                AppImages.contact2,
                                height: 28.0.h,
                                width: 35.0.w,
                              ),
                            ),
                            Image.asset(
                              AppImages.contact3,
                              height: 28.0.h,
                              width: 35.0.w,
                            ),
                            GestureDetector(
                              child: Image.asset(
                                AppImages.contact4,
                                height: 28.0.h,
                                width: 35.0.w,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  margin: 69),
              const Padding(
                padding: EdgeInsets.only(top: 13.0, left: 157),
                child: CircleAvatar(
                  radius: 50.0,
                  backgroundImage: AssetImage(AppImages.userImage),
                ),
              ),
            ],
          ),
          Expanded(
            child: ListView.builder(
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 13, left: 29),
                    child: CustomText(
                      text: "27 December",
                      style: Theme.of(context).textTheme.displayLarge,
                    ),
                  ),
                  customContainer(
                    context: context,
                    margin: 15,
                    child: Column(
                      children: [
                        ListTile(
                          leading: Image.asset(
                            AppImages.outGoingCall,
                            height: 21.33,
                            width: 32,
                          ),
                          title: CustomText(
                            text: "8:19 pm",
                            style: Theme.of(context).textTheme.displayLarge,
                          ),
                          subtitle: CustomText(
                            text: "Outgoing call,  20 mins 50 secs",
                            style: Theme.of(context).textTheme.headline4,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 9),
                          child: ListTile(
                            leading: Image.asset(
                              AppImages.missingCall,
                              height: 21.33,
                              width: 32,
                            ),
                            title: CustomText(
                              text: "5:05 pm",
                              style: Theme.of(context).textTheme.displayLarge,
                            ),
                            subtitle: CustomText(
                              text: "Missed call",
                              style: Theme.of(context).textTheme.headline4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              itemCount: 7,
            ),
          )
        ],
      ),
    );
  }
}

Widget customContainer({Widget? child, double? margin, context}) {
  return Container(
    margin: EdgeInsets.only(top: margin!),
    width: 414.w,
    height: 161.h,
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(37.0),
        color: Theme.of(context).primaryColor),
    child: child,
  );
}
