import 'package:eary/core/config/localization/languages/appStrings_strings.dart';
import 'package:eary/modules/authontication/model/user.dart';
import 'package:eary/modules/authontication/view_model/auth_bloc.dart';
import 'package:eary/modules/lay_out/view/widgets/edit_profile_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firestore_model/firestore_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../../core/utilites/app_images.dart';
import '../../../../../core/utilites/font_manager.dart';
import '../../../../../core/widgets/custom_text.dart';
import '../../../../../core/widgets/default_button.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    AuthBloc().getUser();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 0.0,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Theme.of(context).canvasColor,
          ),
        ),
      ),
      body: ModelStreamSingleBuilder<UserModel>(
        docId: FirebaseAuth.instance.currentUser?.uid,
        onLoading: () => const Center(
          child: CircularProgressIndicator(),
        ),
        onSuccess: (user) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsets.only(top: 38.h),
                child: Center(
                  child: Container(
                    height: 120,
                    width: 120,
                    clipBehavior: Clip.antiAlias,
                    decoration: const BoxDecoration(shape: BoxShape.circle),
                    child: user?.imageUrl == null
                        ? Image.asset(
                            AppImages.userImage,
                            fit: BoxFit.fitWidth,
                          )
                        : Image.network(user!.imageUrl!, fit: BoxFit.cover),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 18.0),
                child: Center(
                  child: CustomText(
                    text: AppStrings.info,
                    style: Theme.of(context)
                        .textTheme
                        .displayLarge!
                        .copyWith(fontSize: 24),
                  ),
                ),
              ),
              SizedBox(
                height: 21.91.h,
              ),
              containerBody(user, context),
              const SizedBox(
                height: 70,
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Center(
                  child: DefaultButton(
                    height: 44.h,
                    width: 316.w,
                    color: Theme.of(context).dialogBackgroundColor,
                    backGroundcolor: Theme.of(context).canvasColor,
                    text: AppStrings.editProfile,
                    fontSize: 18.sp,
                    fontWeight: FontWeight.w400,
                    fontFamily: AppFontFamily.poppinsFamily,
                    onPressed: () {
                      showModalBottomSheet(
                        context: context,
                        barrierColor: Theme.of(context).primaryColor,
                        backgroundColor: Theme.of(context).dialogBackgroundColor,
                        elevation: 10,
                        // shape: RoundedRectangleBorder(
                        //   borderRadius: BorderRadius.circular(20.0),
                        // ),
                        builder: (BuildContext context) {
                          return EditProfileWidget(user: user);
                        },
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

Widget containerBody(UserModel? user, context) {
  return Container(
    margin: EdgeInsets.only(top: 13.5.h, left: 31.w, right: 27.h),
    padding: const EdgeInsets.all(10),
    width: 324.w,
    height: 200.h,
    decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20.0.r),
        color: const Color(0xffE4EBF9)),
    child: SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomText(
            text: user?.userName ?? '',
            style: Theme.of(context)
                .textTheme
                .titleMedium!
                .copyWith(fontSize: 22, fontFamily: AppFontFamily.inter),
          ),
          SizedBox(
            height: 11.12.h,
          ),
          const Divider(
            height: 6,
            color: Colors.white,
          ),
          SizedBox(
            height: 21.21.h,
          ),
          CustomText(
            text: user?.email,
            style: Theme.of(context)
                .textTheme
                .titleMedium!
                .copyWith(fontSize: 22, fontFamily: AppFontFamily.inter),
          ),
          SizedBox(
            height: 11.12.h,
          ),
          const Divider(
            height: 1,
            color: Colors.white,
          ),
          SizedBox(
            height: 21.21.h,
          ),
          CustomText(
            text: "Female",
            style: Theme.of(context)
                .textTheme
                .titleMedium!
                .copyWith(fontSize: 22, fontFamily: AppFontFamily.inter),
          ),
          SizedBox(
            height: 11.12.h,
          ),
          const Divider(
            height: 1,
            color: Colors.white,
          ),
          SizedBox(
            height: 21.21.h,
          ),
        ],
      ),
    ),
  );
}
