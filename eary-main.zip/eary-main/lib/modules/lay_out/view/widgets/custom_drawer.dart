import 'package:eary/core/app_routes/routes_mames.dart';
import 'package:eary/core/config/localization/languages/appStrings_strings.dart';
import 'package:eary/core/utilites/app_images.dart';
import 'package:eary/core/utilites/font_manager.dart';
import 'package:eary/core/widgets/custom_text.dart';
import 'package:eary/modules/authontication/view_model/auth_bloc.dart';
import 'package:eary/modules/lay_out/view/widgets/settings_bottom_sheet.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'drawer_item.dart';

class CustomDrawer extends StatelessWidget {
  const CustomDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Drawer(
         backgroundColor: Theme.of(context).primaryColor,
        child: Container(
          margin: const EdgeInsets.only(top: 10, left: 21),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: CustomText(
                  text: AppStrings.eary,
                  style: Theme.of(context).textTheme.titleMedium!.copyWith(fontFamily: AppFontFamily.fingerPaintFamily),
                ),
              ),
              SizedBox(
                height: 29.h,
              ),
              DrawerItem(
                text: AppStrings.yourProfile,
                image: AppImages.editProfile,
                imageHeight: 17,
                imageWidth: 17.86,
                onTap: () {
                  Navigator.pushNamed(context, RoutsNames.profile);
                },
              ),

              DrawerItem(
                  text: AppStrings.settings,
                  image: AppImages.settings,
                  imageHeight: 20,
                  imageWidth: 20,
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      elevation: 10,
                      builder: (BuildContext context) {
                        return const SettingsBottomSheet();
                      },
                    );
                    // Navigator.pushNamed(context, RoutsNames.settings);
                  }),
              DrawerItem(
                  text: AppStrings.logOut,
                  image: AppImages.logOut,
                  imageHeight: 18,
                  imageWidth: 18,
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          backgroundColor: Theme.of(context).primaryColor,
                          title: CustomText(
                            text: AppStrings.areYouSureLogout,
                            style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: AppFontSize.s24),
                          ),
                          actions: <Widget>[
                            MaterialButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text(AppStrings.cancel),
                            ),
                            MaterialButton(
                              onPressed: () {
                                AuthBloc().logOut(context);
                              },
                              child: Text(AppStrings.ok),
                            ),
                          ],
                        );
                      },
                    );
                  }),
            ],
          ),
        ),
      ),
    );
  }
}
