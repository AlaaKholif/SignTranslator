class OnBoardingModel {
  final String? title, description, image;

  OnBoardingModel({this.title, this.image, this.description});
}
