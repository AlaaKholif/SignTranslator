import 'package:eary/core/widgets/custom_text.dart';
import 'package:eary/on_boarding/model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class OnBoardingItem extends StatelessWidget {
  final OnBoardingModel? onBoardingModel;
  const OnBoardingItem({Key? key, this.onBoardingModel}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            height: 414,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
                borderRadius: BorderRadius.circular(30.0)),
            child: Image.asset(onBoardingModel!.image!),
          ),
          SizedBox(
            height: 25.h,
          ),
          CustomText(
            text: onBoardingModel!.title!,
           style:Theme.of(context).textTheme.bodyLarge,
          ),
          SizedBox(
            height: 8.h,
          ),
          CustomText(
            text: onBoardingModel!.description!,
            style:Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}
